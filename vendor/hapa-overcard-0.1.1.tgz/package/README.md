# Hapa Overcard

<!-- HAPA_ECOSYSTEM_CONTEXT_START -->
## Hapa ecosystem context

Unless this repository explicitly declares a narrower, evidence-backed maturity for a particular capability, treat its Hapa-facing work as **First Pass / Prototype Stage**. Interfaces and workflows may change. There is no general promise of stability, compatibility, uptime, production support, or fitness for a particular use. A label such as **Core** describes current ecosystem importance, not production readiness; a declared release, verified state, MVP, scaffold, or archive status applies only to the named surface and supporting evidence.

Use Hapa as an artist kit. Apps and nodes are work surfaces or specialized paints; Cards and Decks are reusable swatches, recipes, constraints, and remembered techniques; agents are paintbrushes that apply and combine them; Hapa protocols keep the canvas attributable, bounded, and reversible. Start from the closest existing app, Card, agent pattern, or protocol as a **jump-off point**, adapt that pre-existing wisdom to the new problem, verify the result, and preserve source ownership, custody, licenses, attribution, and lineage.

Calder welcomes **for-profit and nonprofit teams and organizations** to suggest a clearly attributed ecosystem presence, service integration, public-interest pilot, connector, Card/Deck, agent route, or future decentralized-commerce experiment. This is an open invitation to explore, not a promise of partnership, acceptance, compatibility, decentralization, funding, commerce capability, or commercial outcome. Canonical guidance: `$HAPA_FRONT_DOOR_ROOT/docs/ECOSYSTEM_STAGE_AND_PARTICIPATION.md` ([public copy](https://github.com/calderwong/hapa/blob/main/docs/ECOSYSTEM_STAGE_AND_PARTICIPATION.md)).
<!-- HAPA_ECOSYSTEM_CONTEXT_END -->

## Place in the Hapa artist kit

Overcard is reusable studio technique rather than a finished painting. It gives
Hapa apps one common way to carry a Hand, assemble Decks, place entities,
describe Formations, attach context to typed hosts, and bind bounded process
responsibility without turning visual layout into authority.

| Question | Truthful answer |
| --- | --- |
| Best jump-off point for | Any Hapa app that needs portable Hand/Deck state, spatial arrangement, typed attachments, or explicit responsibility bindings. |
| Inputs it accepts | Consumer-owned entity references, privacy-safe summaries, host declarations, expected revisions, and explicit commands. |
| Records it owns | Shared schemas, reducers, migrations, host/event contracts, conformance fixtures, and package implementations. |
| What consumers still own | Native records, rendering/resolution adapters, authentication, process lifecycle, permissions, and any domain-specific source truth. |
| Current consumers | Hapa Dev Proto is the reference consumer; Avatar Builder is the first independent consumer. |

**Current state:** package version `0.1.1` is a private pre-release and the node
manifest says `implementation-in-progress`. Implemented and passing package/host
surfaces are usable jump-off points, but npm publication, broad consumer
migration, compatibility, and stable public API are not guaranteed.

Canonical Hapa capability for picking up cards and avatars, carrying a shared Hand across applications, arranging spatial Formations, attaching context to typed application hosts, and explicitly assigning bounded responsibility to processes.

Status: `0.1.1` private pre-release; canonical core, host, React integration, Hand, pickup, spatial overlay, HostTarget slots, migration, sync, policy, and packed conformance are implemented and verified. Consumer migration and release gates remain tracked on the board.

## Why this exists

Hapa Dev Proto contains a strong reference implementation, but its public placement SDK and live app code diverged. Hapa Avatar Builder also contains valuable inventory and 3D held-card mechanics. Copying either implementation into the other app would create a third state system and guarantee drift.

This repo is the maintained-once boundary. Dev Proto, Avatar Builder, and future nodes consume the same package and local state host through thin adapters.

## Invariants

- Placement answers where an entity is shown.
- Attachment answers what context it contributes to a host.
- Formation answers which entities belong together and their semantic roles.
- Responsibility answers who or what may act for a typed process role.
- Visual proximity is never authority.
- Private memory and credential values do not enter portable state.
- Every mutation is revisioned, reversible, and auditable.

## Package surface

One umbrella package exposes generated ESM, CommonJS, and declaration artifacts:

- `@hapa/overcard/core`
- `@hapa/overcard/react`
- `@hapa/overcard/electron`
- `@hapa/overcard/host`
- `@hapa/overcard/host/client` (browser-safe)
- `@hapa/overcard/testing`
- `@hapa/overcard/styles`

The legacy `@hapa/placement-sdk` will temporarily re-export compatible symbols and receive no new behavior. Run `npm run check` to build, type-check, exercise the packed-package imports, and run the contract/host tests.

## Local state host

`@hapa/overcard/host` supplies the loopback HTTP host, file repository, and client. The host is the only shared-state writer; applications submit idempotent commands with an expected revision and subscribe to server-sent events. See [`docs/HOST.md`](docs/HOST.md).

## Consumers

- Hapa Dev Proto: reference host for CSS-3D Overcard, Nexus, and Hell Week.
- Hapa Avatar Builder: first independent consumer for the shared Hand, sixteen menu hosts, avatar/card/deck adapters, and the Tarot Draw 3D field.
- Future Hapa nodes: install a pinned package, declare a node adapter manifest, register entity renderers/resolvers and HostTargets, then run the conformance suite.

## Coordination

Implementation truth lives in this repo and the owning consumer repos. Coordination truth is append-only on the `hapa-app-hapa-avatar-builder` board:

<http://127.0.0.1:5181/?project=hapa-app-hapa-avatar-builder>

Start with [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md), [`docs/ADOPTION_DEPLOYMENT_VERSIONING.md`](docs/ADOPTION_DEPLOYMENT_VERSIONING.md), [`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md), [`docs/COMPATIBILITY_MATRIX.md`](docs/COMPATIBILITY_MATRIX.md), [`docs/MIGRATION_RECOVERY_RELEASE_RUNBOOK.md`](docs/MIGRATION_RECOVERY_RELEASE_RUNBOOK.md), [`docs/RELEASE_PIPELINE.md`](docs/RELEASE_PIPELINE.md), and [`docs/PROTOCOL_REFERENCE.md`](docs/PROTOCOL_REFERENCE.md). Ownership decisions are in [`ADR-0001`](docs/decisions/ADR-0001-CANONICAL-OVERCARD-OWNERSHIP.md) and [`ADR-0002`](docs/decisions/ADR-0002-VISUAL-PROXIMITY-IS-NOT-AUTHORITY.md).

## Publication and license boundary

The Overcard implementation is Hapa-authored; consumer records and third-party
dependencies retain their own ownership and licenses. No repository-wide
license grant is currently declared. Public visibility is not npm publication
and does not by itself grant reuse rights or promise support.
