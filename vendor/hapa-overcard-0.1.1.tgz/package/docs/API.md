# Hapa Overcard API

## Scope and activation

Overcard is a reusable package, not a permanently running service. A consumer
opens a `FileOvercardRepository` and passes it to `startOvercardServer()`.
The server binds only to loopback (`127.0.0.1`, `::1`, or `localhost`), and
the consumer owns the port, bearer token, and allowed browser origins.

```ts
import { FileOvercardRepository, startOvercardServer } from '@hapa/overcard/host';

const repository = await FileOvercardRepository.open({
  eventLogPath: '/private/local/overcard-events.ndjson',
  snapshotPath: '/private/local/overcard-snapshot.json'
});
const running = await startOvercardServer({ repository, token: process.env.HAPA_OVERCARD_TOKEN });
```

Discovery never grants trust or execution authority. A consumer must provide
an explicit matching grant before it can activate responsibility-bearing work.

## Routes

| Method | Route | Result |
| --- | --- | --- |
| `GET` | `/health` | Capability envelope, current revision, and hash-chain tip. |
| `GET` | `/capabilities` | The same discovery envelope for clients. |
| `GET` | `/snapshot` | Current validated shared-state projection. |
| `POST` | `/commands` | Revision-checked `state.upsert` or `state.delete` command. |
| `GET` | `/events?afterRevision=N` | Replay plus live server-sent events. |

When a token is configured, send `Authorization: Bearer <token>` on every
request. Invalid input, stale revisions, unsafe payloads, and unauthorized
requests return machine-readable JSON errors. Command bodies are capped at
1 MiB and may not contain credential-shaped values or raw private memory.

## Verification

`npm test` validates the HTTP host, client synchronization, capability
envelope, event hash chain, and Electron/React adapter contract.
