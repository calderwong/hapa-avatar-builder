# Overcard host fault matrix

Verified 2026-07-11 against `test/host-supervisor.test.mjs`, `test/host.test.mjs`, `test/store-reconnect.test.mjs`, and `test/sync.test.mjs`.

| Fault | Expected result | Automated evidence |
| --- | --- | --- |
| Host absent or delayed | Store reports reconnecting, bounded retry reaches Ready once the host appears | `store automatically recovers` |
| UI-port collision / wrong service | Specific `wrong-service`; no overwrite or wildcard trust | `probe and ensure reject wrong services` |
| Stale discovery | Dead endpoint is reprobed and replaced atomically | `stale discovery is replaced` |
| Disallowed CORS origin / blind form-like POST | HTTP 403 before routing; wrong command media type is 415; repository revision is unchanged | `denied browser origins and non-JSON command posts cannot mutate the host` |
| Compatible host missing caller origin | Typed `origin-blocked` with exact `missingOrigins`; UI does not misreport generic offline | supervisor probe test |
| Consumer launched after host owner | Requested exact origin is registered durably and admitted without owner restart | Builder-first / Dev-Proto-first launch-order test |
| Unauthorized or incompatible host | Typed `unauthorized` / `incompatible` diagnosis | supervisor probe test |
| Simultaneous Builder/Dev Proto start | Exactly one embedded owner and one external consumer | supervisor race test |
| Legacy root plus dead/live discovery | Dead owner does not strand migration; live owner fails closed without overwriting | legacy data-root migration tests |
| Owner crash/restart | Durable revisioned state reloads from the shared data root | stale discovery/restart test |
| Owner shutdown with idle SSE client | Active event streams are ended and host close resolves promptly | `host close is bounded while an idle SSE subscriber is connected` |
| SSE revision gap | Late subscriber replays revisions in order | `late subscribers replay` |
| Idle stream reconnect | `onOpen` resets backoff and reports online without waiting for a mutation; prior streams are aborted before retry | idle/repeated reconnect sync tests |
| Offline mutation | Reject policy creates no pending record; queue policy labels records uncommitted | sync tests |
| Conflict | Remains inspectable until explicit rebase or discard | sync and recovery presenter tests |
| Abort/backoff/rapid reconnect | Timers stop and subscription count remains one | store reconnect tests |

The supervisor closes only an embedded handle it owns. Closing an external handle is a no-op. Discovery metadata contains no token or credential.
