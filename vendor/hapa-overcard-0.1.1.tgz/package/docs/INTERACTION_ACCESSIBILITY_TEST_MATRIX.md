# Interaction, accessibility, and visual regression matrix

This matrix is the release gate for the shared Overcard interaction layer. Consumer apps may render native faces or a native Three.js scene, but they inherit these commands and recovery guarantees from `@hapa/overcard`.

| Risk | Permanent proof | Required recovery |
| --- | --- | --- |
| Click accidentally starts a drag | `pickup.test.mjs` keeps threshold pickup separate from explicit click | source remains unchanged |
| Native drag ends outside every target and leaves a stuck held card | `pickup.test.mjs` exercises `dragend`, lost pointer capture, and cancelled movement | held state clears without removing the source |
| Card is lost when persistence fails | Hand and slot commits clear held state only after a successful canonical commit | visible error plus original source/held state |
| Precision drag is unavailable | `hand.test.mjs` covers Enter, Escape, Delete, Undo, active-descendant focus; `slots.test.mjs` covers Stage, Earlier/Later, Detach + return, and Undo buttons | every mutation has a keyboard/click path |
| Menu attachment cannot be removed | `slots.test.mjs` executes Detach + return and Undo | placement returns to Hand and attachment is removed atomically |
| Card is offscreen in CSS or Three.js | `spatial.test.mjs` covers semantic nudge/layout/recover; `visual-contract.test.mjs` covers the CSS/Three projection contract | Recover all uses the same canonical command |
| State is conveyed by color alone | `visual-contract.test.mjs` asserts status/mode/health attributes; shared CSS uses text, border pattern, glyph-ready attributes, and focus outlines | staged, active, paused, degraded, and offline remain distinguishable |
| Reduced motion causes unusable movement | shared CSS removes transitions under `prefers-reduced-motion`; Dev Proto `formationVisualLanguage.test.mjs` removes activity motion | all commands remain available |
| Builder and Dev Proto drift | `two-app-consumers.test.mjs` imports both real adapters; consumer suites assert their actual mounts | canonical package remains the behavior owner |

## Consumer coverage

- Hapa Avatar Builder: `tests/overcard-root.test.mjs`, `tests/overcard-menu-slots.test.mjs`, `tests/overcard-pickup-surfaces.test.mjs`, and `tests/overcard-tarot-formation.test.mjs` cover the persistent Hand, real menu slots, pickup families, and Tarot 3D Formation projection.
- Hapa Dev Proto: `tests/placementAccessibility.test.mjs`, `tests/formationVisualLanguage.test.mjs`, and the Nexus visual QA harness cover pointer-overlay recovery, keyboard movement, Return-to-Hand, non-color state tokens, reduced motion, and live Three.js canvas states.
- Canonical package: `pickup.test.mjs`, `hand.test.mjs`, `slots.test.mjs`, `spatial.test.mjs`, `visual-contract.test.mjs`, and `two-app-consumers.test.mjs` are the cross-node release contract.

Visual review must never be treated as evidence of active authority. Responsibility remains staged until a separately verified binding is granted.
