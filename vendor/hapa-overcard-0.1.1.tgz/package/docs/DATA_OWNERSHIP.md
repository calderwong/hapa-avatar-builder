# Data ownership and source truth

## Where shared behavior changes

Shared schemas, validation, commands, policy, migration planning, and deterministic layout belong in `src/core`. Shared provider/hooks/components belong in `src/react`. The loopback host, file repository, HTTP/SSE transport, backups, and migration coordinator belong in `src/host`. Electron channel names and channel validation belong in `src/electron`. Cross-consumer fixtures and conformance belong in `src/testing`. A consumer adapter may resolve its native entities, render native faces, register typed HostTargets, and call native processes; it may not copy or fork these reducers.

## Verified ownership hierarchy

| Record | Authoritative owner | Projection/cache | Delete or rollback owner |
| --- | --- | --- | --- |
| Native avatar/card/media | Its source Hapa node | EntityRef/catalog | Source node |
| Hand/Deck/Set membership | Canonical collection-ledger record | Consumer inventory bridge | Canonical host; source bridge reverses accepted projection |
| Placement/Attachment | Canonical placement-ledger record | CSS/Three renderer state | Canonical host via inverse/detach/return command |
| Formation/ResponsibilityBinding | Canonical host records | Consumer editors/runtime previews | Canonical host; revocation is explicit and auditable |
| RuntimeContext | Resolver output for a specific run | Redacted telemetry | Process adapter/run owner |
| Event log/snapshot | `FileOvercardRepository` | HTTP/SSE clients | Host operator restores the pair; individual events are never edited |
| Renderer preferences | Consumer-local storage | None | Consumer/operator |
| Credentials/private memory | Keys/memory owner, referenced only by ID | Never portable | Owning keys or memory node |

The append-only event log is durable truth. Its compact snapshot is a verified checkpoint. Consumer stores are projections. Migration backups and receipts remain until release acceptance. Deleting a visual card never deletes the native entity; it removes or returns a placement. Deleting source data remains the source node's responsibility.

## Implemented versus intended

Implemented through `0.1.1`: schemas, ledgers/inverses, least-privilege policy, loopback HTTP/SSE host, file repository/hash chain, React provider/Hand/pickup/spatial/slots, capability negotiation, sync/recovery queue, migration planner/coordinator, durable origin registration, legacy host-root adoption, and packed conformance. Board cards not Done are intended roadmap and must not be described as available runtime behavior.
