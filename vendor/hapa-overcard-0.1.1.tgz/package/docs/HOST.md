# Local Overcard Host

The local host is the single shared-state writer for independently running Hapa applications. Consumer apps do not coordinate by editing a common JSON file.

## Guarantees

- Binds only to `127.0.0.1`, `::1`, or `localhost`.
- Accepts a bearer token and an explicit exact browser-origin registry.
- Rejects every request carrying an unregistered browser `Origin` with HTTP 403 before routing; command posts must be `application/json`.
- Serializes commands inside one repository process.
- Requires an `expectedRevision` for optimistic concurrency.
- Returns the original event when an `idempotencyKey` is retried.
- Appends a SHA-256-linked event before projecting it into current state.
- Writes compact snapshots atomically and verifies their hash on restart.
- Replays and validates the full event hash chain before accepting a snapshot checkpoint.
- Streams replay and live events over server-sent events.
- Rejects credential-shaped values, raw memory content, cycles, and non-JSON values. Safe references such as `secretRef` are allowed.
- Reports availability separately from `trusted` and `authorized`; a running host grants no process authority.

## Routes

| Method | Route | Purpose |
| --- | --- | --- |
| `GET` | `/health` | Capability envelope plus revision and last hash. |
| `GET` | `/capabilities` | Same negotiation envelope for discovery clients. |
| `GET` | `/snapshot` | Current validated projection. |
| `POST` | `/commands` | Revision-checked `state.upsert` or `state.delete`. |
| `GET` | `/events?afterRevision=N` | Replay plus live SSE subscription. |

The generic state commands are a persistence spine. Domain command compilers for Hand, Placement, Formation, attachment, and responsibility remain responsible for producing validated domain records and inverse operations.

## Minimal use

```ts
import {
  FileOvercardRepository,
  OvercardHttpClient,
  startOvercardServer,
} from '@hapa/overcard/host';

const repository = await FileOvercardRepository.open({
  eventLogPath: '/private/local/path/overcard-events.ndjson',
  snapshotPath: '/private/local/path/overcard-snapshot.json',
});

const running = await startOvercardServer({
  repository,
  token: process.env.HAPA_OVERCARD_TOKEN,
  allowedOrigins: ['http://127.0.0.1:5181'],
});

const client = new OvercardHttpClient({
  baseUrl: running.url,
  token: process.env.HAPA_OVERCARD_TOKEN,
});
```

Use an OS-managed secret reference or process environment for the bearer token. Never put the token in an Overcard record, event, or Formation.

## Recovery

Startup refuses a snapshot with a bad hash, a snapshot whose checkpoint does not match the event stream, or an event log with a broken hash link. Preserve both files for inspection; do not silently discard the stream. A later recovery tool may rebuild a new projection from a verified prefix, but must never rewrite the original log.

## Canonical supervisor and discovery

Use `ensureLocalOvercardHost()` rather than app-owned probing/spawning. It reserves loopback HTTP port `8794` by default, reuses a compatible winner, rejects wrong/unauthorized/incompatible listeners, and starts one embedded host only when absent. Durable state lives at `~/.hapa/overcard/`; `host-discovery.json` is atomic metadata and contains no credential. An external handle closes as a no-op; an embedded handle removes only discovery metadata bearing its owner instance id.

Every ensure call validates its requested exact loopback origins and idempotently registers them in `renderer-origins.json`. The supervisor unions those registrations with the canonical Dev Proto and Avatar Builder launch profiles before starting a host. A canonical running host consults that registry for each origin-bearing request, so a later Hapa consumer can register a new exact loopback origin without restarting the current owner. `probeOvercardHost(baseUrl, { requiredOrigins })` verifies the effective CORS response and returns typed `origin-blocked` plus `missingOrigins` instead of mislabeling this failure as an unavailable host. Historical registry entries are not re-probed on every ensure, so registry growth does not turn startup into an unbounded request fan-out.

`null` is deliberately not in the canonical baseline. A packaged local-file Electron consumer may explicitly register `null` as a compatibility exception, but opaque origins are not distinguishable from one another. That exception should be replaced with a stable custom application scheme or an authenticated preload/IPC bridge. CORS is a browser boundary, not process authorization; use the bearer-token option where other local processes are outside the trust boundary.

Electron consumers ensure before renderer hydration and expose only scoped status/ensure/reconnect operations. Web/API launchers ensure the same host when they possess process authority. Renderer code only reconnects its store; it never spawns a process. Register exact loopback origins—never wildcard CORS or disabled web security.

Initial load and later stream failures retry with bounded backoff and one subscription. A validated SSE open marks the transport online even when the Hand has no new events; gap failures abort the prior stream before retry. Host shutdown ends active SSE streams before closing, so an Electron quit/restart cannot wait forever on an idle renderer. “Host connected” and “pending commands synchronized” are separate outcomes. See `HOST_FAULT_MATRIX.md` for stale discovery, launch races, restart, replay-gap, CORS, version, authorization, and rollback evidence.

## One-time legacy data-root adoption

`migrateLegacyOvercardDataRoot({ legacyDataRoot, dataRoot? })` copies only `overcard-events.ndjson` and `overcard-snapshot.json` into the canonical root. It never changes the legacy files, never overwrites different canonical state, verifies SHA-256 after copy, and writes a deterministic receipt under `migration-receipts/`. A repeated migration validates the source, target, and receipt before returning `already-migrated`; missing or tampered targets fail closed. Dead discovery metadata does not block migration, while a live owner returns `target-in-use`.

For the initial ecosystem cutover, stop every Overcard consumer, run the Dev Proto legacy migration first, verify its receipt, and only then start either consumer. If Avatar Builder has already opened an empty canonical host, migration correctly returns `target-in-use`; stop consumers and repeat from the preserved legacy root. After the receipt exists, ordinary Builder-first or Dev-Proto-first launches are independent.
