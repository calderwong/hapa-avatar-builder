# Install and release pipeline

The source checkout is for canonical development. Packaged Hapa nodes must depend on an exact `@hapa/overcard` version and preserve the release SHA-256 in `overcard-release.lock.json`; they must not package another application's source path.

## Promote a local release candidate

From the canonical checkout:

```sh
npm run release:local
```

The command builds first so the packed bytes are the exact tested bytes, runs the machine-readable release gates, packs the public subpaths, computes SHA-256 and SRI integrity, writes a candidate manifest, and temporarily updates the Builder and Dev Proto consumer locks. The canary verifies the tarball bytes against that manifest, installs that exact tarball with npm in an isolated directory, then temporarily materializes the installed package in each consumer while its build and focused tests run. Passing against mutable development `file:` links is not release evidence.

Before temporary candidate locks are written, their exact prior bytes (or absence) are captured. A rejected candidate or any release/canary error restores both prior locks; only a promoted candidate retains new locks. The compatibility gate also requires the package manifest, package lock, compiled `OVERCARD_PACKAGE_VERSION`, and compatibility matrix to name the same version.

The promotion gates are:

1. canonical build, typecheck, unit, packed-export, two-app, interaction, and installer tests;
2. Avatar Builder production build and focused Overcard/Hand/menu/Tarot/Hell Week/host-lifecycle and recovery canary;
3. Dev Proto TypeScript build and focused package/accessibility/capability/run-context/host-lifecycle/startup-guard canary;
4. bounded global-Hand bootstrap, 10k Builder catalog, 1k Tarot 3D, and 10k Dev Proto Formation performance/memory budgets;
5. compatibility matrix, required documentation, idempotent migration, and restoration of an exact pre-candidate event/snapshot pair.
6. Header dock/floating accessibility, six-viewport Builder visual baselines, host fault injection, no-fork presenter audit, and presentation-preference migration.

The manifest becomes `promoted` only when both `release-gates-report.json` and `canary-report.json` are healthy. A failed gate writes a `rejected` manifest and bounded evidence. The performance measurements are also emitted as `performance-report.json`. The local artifact and evidence live under `releases/<version>/`; publishing to a registry is a separate human-authorized action.

Verify an artifact before installing it:

```sh
node bin/hapa-overcard.mjs verify-release \
  --release-manifest releases/0.1.1/manifest.json
```

## Adopt from a third Hapa node

The scaffold command changes only thin integration files. It never copies collection, placement, sync, policy, or UI behavior:

```sh
node /path/to/hapa-overcard/bin/hapa-overcard.mjs scaffold \
  --node-root /path/to/new-hapa-node \
  --node-id hapa-example-node \
  --release-manifest /path/to/hapa-overcard/releases/0.1.1/manifest.json
```

It verifies the artifact checksum, pins the exact package version, creates the consumer lock and capability adapter manifest, and adds a minimal sync-adapter module. It refuses to overwrite an existing adapter.

Development `file:` links may remain in a working checkout for rapid iteration, but `overcard-release.lock.json` sets `packaging.sourceLinksAllowed` to `false` and names the exact deployment specifier. Packaging and promotion checks consume the lock, not the development link.
