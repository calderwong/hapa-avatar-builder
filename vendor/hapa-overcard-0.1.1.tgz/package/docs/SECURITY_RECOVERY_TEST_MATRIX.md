# Security, degraded operation, and recovery test matrix

The release suite treats visual placement, network discovery, embedded messaging, and queued offline work as untrusted until their separate policy gates succeed.

| Risk | Fail-closed behavior | Evidence |
| --- | --- | --- |
| Raw private memory or credential value | shared client rejects before send or queue; host independently rejects with path | `security-recovery.test.mjs`, `host.test.mjs` |
| Untrusted/incompatible/unauthorized runtime | effective permissions, tools, memory, secret refs, and execution are empty | `policy.test.mjs` |
| Missing human gate or staged binding | degraded context only; no process execution | `policy.test.mjs` |
| Unknown iframe origin/schema/version/capability/action | typed rejection; no session or action | Builder `overcard-embedded-bridge.test.mjs` |
| Host unavailable | command is visibly pending, never reported shared | `security-recovery.test.mjs`, `sync.test.mjs` |
| Stale concurrent edit | explicit conflict, source preserved, operator chooses rebase/discard | `sync.test.mjs`, `two-app-consumers.test.mjs` |
| Tampered event/snapshot | reopen fails before projecting state | `host.test.mjs` |
| Lost/stuck placement | canonical Return, Recover All, and inverse event | `placement-ledger.test.mjs`, `interaction-accessibility-test-matrix` |

All secrets in tests are scheme-only references or visibly synthetic sentinel labels. Tests must never use live keys, private memory, active leases, or real external authority. Every fallback is deterministic (`process-default`, `pause`, or `fail`) and every successful recovery appends one attributable event.
