# ADR-0001: Canonical Overcard ownership

- Status: accepted
- Date: 2026-07-10
- Human evidence: the project owner directed Codex to drain and begin executing the reviewed Universal Overcard board.
- Coordination board: `hapa-app-hapa-avatar-builder`

## Context

Hapa Dev Proto has a local Formation/Overcard implementation and a separate minimal `@hapa/placement-sdk` that production does not consume. Hapa Avatar Builder has per-avatar Hand/Deck scaffolding and a sophisticated private 3D held-card engine inside Tarot Draw. Copying Dev Proto UI/state into Builder would create another implementation and allow both applications to drift.

A package without a shared runtime authority also cannot keep the Hand synchronized between independently running Electron/web applications. Direct shared-file writes and cross-app localStorage are not safe concurrency models.

## Decision

Create one independent canonical codebase at:

```text
<repository-root>/hapa-overcard
```

It owns one umbrella package named `@hapa/overcard` with isolated `core`, `react`, `electron`, `host`, `testing`, and `styles` subpaths. The local host implementation lives in the same repo/package release train so contract and runtime behavior cannot version independently by accident.

Hapa Dev Proto is the reference consumer. Hapa Avatar Builder is the first independent consumer. Future nodes install the same pinned package and provide only thin adapters.

The Hapa Design System may supply tokens and generic primitives, but it does not own Overcard feature behavior. Native app presentation enters through theme and entity-renderer adapters.

## Compatibility alias

`@hapa/placement-sdk` becomes a temporary compatibility alias:

- it re-exports compatible canonical symbols from `@hapa/overcard`;
- it receives no new schemas, validators, reducers, or feature behavior;
- usage emits or documents a deprecation notice;
- it remains until Dev Proto and Avatar Builder both pass the installed-package conformance suite and one rollback-capable release;
- it is removed only in a separately versioned breaking release with migration notes.

## Rejected alternatives

### Keep shared source inside Hapa Dev Proto

Rejected because a consumer would depend on another application's dirty source tree and release cadence, and the current app already diverges from its public SDK.

### Copy the feature into Avatar Builder

Rejected because bug fixes and enhancements would immediately require duplicate work.

### Split core, client, React, and host into independently versioned packages

Rejected for the first implementation because the operator requested one maintained codebase and independent versions would enlarge the compatibility surface. Subpath exports preserve isolation without fragmenting ownership.

### Use only localStorage or a directly shared JSON file

Rejected because two apps need revisions, idempotency, concurrency control, subscriptions, recovery, and a single writer boundary.

## Consequences

- A new canonical repo/package/host must be built and registered.
- Both existing apps require migration rather than copy/paste integration.
- Shared feature enhancements ship once and are proven through both consumer canaries.
- App-specific adapters remain intentionally small and source-owning.
- The release gate must include package integrity, schema compatibility, state migration, two-app round trips, documentation, and rollback proof.
