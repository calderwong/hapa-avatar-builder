# ADR-0002: Visual proximity is not authority

Status: accepted, 2026-07-10.

Placing an avatar or card near a menu item is a reversible visual operation. It may stage view or process context, but it cannot grant execution authority. Responsibility requires a typed process socket, a canonical ResponsibilityBinding, explicit trust and authorization grants, least-privilege policy compilation, required human gates, and an active binding ID. Discovery, compatibility, drag/drop, Formation membership, and a green/healthy display are insufficient.

Consequences: UI labels context and responsibility separately; responsibility remains staged until authorization succeeds; runtimes fail closed on missing grants/secret references/leases; detach or revoke is explicit; telemetry attributes the effective binding and fallback. This prevents an attractive spatial metaphor from becoming an ambient privilege escalation mechanism.
