# Responsibility and Runtime Policy

Placing an avatar or card near a feature is a visual and interaction event. It does not grant authority. A drop may create a staged Attachment or ResponsibilityBinding proposal; only an explicitly activated binding may contribute to runtime policy.

## Effective authority

`compileRuntimePolicy` intersects five independently supplied boundaries:

1. Operator policy: what this human/node permits.
2. Process allowance: what the target process and socket permit.
3. Runtime registration: what the installed, running, compatible, trusted, and authorized adapter can actually enforce.
4. Explicit ResponsibilityBinding grants: what was intentionally assigned to this principal and target.
5. Trusted card constraints: optional reductions to scope or budget. Cards can never add permissions, capabilities, tools, memory visibility, or writeback rights.

A value survives only when every applicable boundary contains it. Limits use the smallest defined value. Fallback uses the safest applicable behavior (`fail`, then `pause`, then process default).

## Fail-closed states

The compiler denies and returns empty effective permission, capability, tool, memory, and secret-reference sets when identity/target matching fails; the principal is unavailable; the runtime is missing, stopped, incompatible, untrusted, or unauthorized; a required permission/capability is absent; a secret reference is invalid; a lease has expired; or a binding is revoked, expired, or removed.

Staged, paused, degraded, conflict, and inactive bindings return a degraded policy and cannot execute the process. Context, advisor, and reviewer modes can never become process operators. Operator execution additionally requires an active execution policy, an authority socket, and all confirmation/human gates.

## Memory and secrets

Memory sources, visibility, and classifications are intersected just like permissions. Raw memory content is not a policy input and is prohibited from portable host state. Writeback must be allowed by every boundary and can require a separately satisfied human gate.

ResponsibilityBinding stores secret references only. The compiler accepts only operator-approved reference schemes and redacts rejected reference values in explanations. Credential values remain in their owning OS keychain or secret provider.

## Provenance

Every result names the binding, process definition/version, principal key, target, and compilation time. RuntimeContext snapshots later persist the resolved, bounded result and source revisions for replay and audit; they do not persist source memory or credentials.
