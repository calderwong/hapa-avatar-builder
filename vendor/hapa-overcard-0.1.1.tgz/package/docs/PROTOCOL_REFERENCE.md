# Protocol, repository, and transport reference

Protocol: `hapa.overcard.v1`. Package: private pre-release `0.1.1`.

## Canonical schemas

| Constant | Schema | Meaning |
| --- | --- | --- |
| `entityRef` | `hapa.entity-ref.v2` | Portable source identity and resolver, never embedded private state |
| `entityCollection` | `hapa.entity-collection.v2` | Owned Hand, Deck, or Set |
| `placement` | `hapa.placement.v2` | Reversible semantic location/pose |
| `attachment` | `hapa.attachment.v1` | View, process, or responsibility relationship to a host |
| `processDefinition` | `hapa.process-definition.v1` | Typed sockets/effects/capacity/gates |
| `responsibilityBinding` | `hapa.responsibility-binding.v2` | Bounded principal, permissions, memory, tools, budget, fallback |
| `formation` | `hapa.formation.v2` | Versioned members, roles, groups, poses, bindings, projections |
| `runtimeContext` | `hapa.runtime-context.v1` | Redacted, revision-pinned effective run input |
| `executionEvent` | `hapa.execution-event.v1` | Append-only, reference-only execution telemetry linked to a RuntimeContext snapshot |
| `capabilityEnvelope` | `hapa.overcard-capabilities.v1` | Installed/running/trusted/compatible/authorized are independent |
| `nodeAdapter` | `hapa.overcard-node-adapter.v1` | Consumer deployment contract |
| `event` | `hapa.overcard-event.v1` | Append-only provenance-bearing event |

Generated JSON Schemas ship under `@hapa/overcard/schemas/*`. Unknown fields are tolerated for forward compatibility; an unknown major schema is rejected.

## Lifecycles and effects

`staged` previews an intended relationship without execution. `active` contributes its declared effect. `paused` remains recorded but inactive. `revoked` permanently removes authority. `degraded` cannot meet dependencies and uses its declared fallback. `conflict` needs explicit rebase/discard/review. `removed` is no longer placed. View context changes presentation only; process context contributes bounded inputs; responsibility can authorize a principal only after policy/gates.

## Commands, events, and errors

Collection commands are `copy`, `move`, `lend`, `assign`, `return`, `remove`, and `reorder`; every accepted mutation returns an inverse. Placement commands contain atomic `placement.upsert/remove`, `attachment.upsert/remove`, and `zone.reorder` operations plus expected ledger revision. Host commands are `state.upsert` or `state.delete` with `idempotencyKey`, `expectedRevision`, actor/time/source/trace provenance.

Repository errors: `revision_conflict` (HTTP 409), `unsafe_payload` (422), invalid JSON/limit/schema request (400), missing route (404), missing/bad bearer token (401). Collection/placement issues include `capacity`, `duplicate`, `owner_scope`, `not_found`, `slot_conflict`, `linked_attachment`, `invalid_operation`, and `non_portable`. Queued/offline client commands require explicit retry, rebase, or discard.

## HTTP and subscriptions

- `GET /health` and `/capabilities`: fail-closed envelope plus revision/hash.
- `GET /snapshot`: verified `hapa.overcard-host-snapshot.v1`.
- `POST /commands`: ≤1 MiB JSON HostCommand; returns the accepted event or an idempotent prior event.
- `GET /events?afterRevision=N`: replay then live SSE event `overcard`.

The server binds loopback only. Optional bearer token and explicit CORS origins are supported. `@hapa/overcard/host/client` is the browser-safe client; `@hapa/overcard/host` contains Node APIs.

## Electron, MIME, and capability discovery

Allowed IPC channels are `hapa-overcard:command`, `:snapshot`, `:subscribe`, and `:health`; every channel must pass `assertAllowedOvercardChannel`. Internal drag adds `application/vnd.hapa.overcard.entity+json` with `{schema:"hapa.overcard-drag-payload.v1",entity:EntityRef}` and does not clear native file types. Node adapters may advertise HTTP, Electron, P2P, and UI discovery, but discovery never sets `trusted` or `authorized` without node-matched grants.

Deep links for legacy Formation navigation remain a compatibility shim in Dev Proto; a canonical cross-node deep-link version is not yet shipped and remains roadmap.

## Safe example

```json
{"schema":"hapa.entity-ref.v2","sourceSystem":"hapa-avatar-builder","entityType":"avatar","entityId":"red-reaper","revision":"42","availability":"available","label":"Red","resolver":{"kind":"api","uri":"http://127.0.0.1:8787/api/avatars/red-reaper"}}
```

Examples contain references only—never credential values, private memory, authorization headers, or raw secret material.
