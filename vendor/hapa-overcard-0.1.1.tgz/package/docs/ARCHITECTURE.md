# Architecture

## One codebase, thin consumers

```mermaid
flowchart LR
  C["@hapa/overcard\ncore + React + Electron + host + testing + styles"]
  H["Local Overcard host\nevents + snapshots + subscriptions"]
  D["Hapa Dev Proto\nreference adapter"]
  A["Hapa Avatar Builder\nentity + host + Tarot adapters"]
  N["Future Hapa node\nthin adapter"]
  C --> H
  C --> D
  C --> A
  C --> N
  D <--> H
  A <--> H
  N <--> H
```

The shared package owns behavior. The host gives independently running applications one revisioned state authority. App adapters preserve source ownership and native presentation.

## Layer responsibilities

### Core

Environment-neutral schemas, validators, migrations, commands, inverse operations, Hand/Deck collections, Placement, Formation, ResponsibilityBinding, RuntimeContext, capabilities, events, deep links, and safe visual-state tokens.

Core must not depend on `window`, `localStorage`, React, Electron, `DOMRect`, or ambient global IDs/clocks.

### React

Storage-agnostic providers and hooks, renderer registry, pointer/keyboard/touch command controller, Hand/Deck shell, floating placement, HostTarget slots, attachment inspector, Formation HUD, accessibility, and theme-token adapters.

### Host

Validated commands, optimistic concurrency, idempotency, append-only events, compact snapshots, live subscriptions, health/capabilities, lazy entity catalog references, compaction, and recovery.

### Electron

Typed IPC registration, preload bridge, repository integration, migration coordination, capability projection, and redacted execution telemetry.

### Testing

Golden fixtures, builders, fake clocks/IDs, in-memory host, migration cases, security cases, interaction harnesses, and the consumer conformance suite.

## Consumer adapter boundary

A consumer registers:

- entity resolvers and safe compact catalog entries;
- renderer IDs for native card/avatar faces;
- HostTargets and typed process sockets;
- privacy-filtered source context resolvers;
- process-specific projection from immutable RuntimeContext;
- native navigation, deep-link, and telemetry destinations.

It does not implement another Hand reducer, Placement ledger, Formation schema, attachment lifecycle, authority compiler, persistence engine, or sync protocol.

## Truth and authority

Source entities remain owned by their native node. Overcard stores stable references, revisions, safe presentation hints, placements, collections, attachments, and explicitly activated bindings.

Effective authority is the intersection of operator policy, process allowance, registered runtime capability, explicit grant, and card constraints. An avatar or card never expands that intersection.
