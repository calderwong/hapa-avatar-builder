# Hand, Deck, and Set Collections

EntityCollection is the durable, source-linked model for a Hand, Deck, or Set. Collection identity includes an owner scope (`operator`, `avatar`, `workspace`, or `node`), so an avatar inventory never silently becomes the operator's personal Hand.

## Durable Hand vs. held card

A Hand is revisioned shared state. A card currently under a pointer, keyboard command, or touch gesture is a `TransientHeldEntity`: an interaction token containing the entity reference and origin, not a second collection and not durable state. Picking up an entity does not remove it. The source changes only after the destination accepts a revision-checked collection command.

This distinction makes cancelled drops, closed windows, lost pointer capture, and host rejection recoverable without losing the card.

## Operations

- `move`: transfer between collections owned by the same principal.
- `copy`: add another reference while retaining the source.
- `assign`: transfer from one owner to an avatar-owned collection and record assigned custody.
- `lend`: transfer across owners and record where the entity must return.
- `return`: follow recorded custody back to the source collection.
- `reorder`: replace member order without changing membership.
- `remove`: internal inverse for a copy; public interfaces should normally say Return Home or remove explicitly.

Each accepted command records actor/time/source/trace provenance, increments every changed collection revision, and returns a replayable inverse command. Before acceptance, capacity, duplicate identity, source membership, owner scope, custody, and expected revisions are checked against an immutable input state.

Entity duplicate checks use stable source/type/id identity rather than revision, preventing two revisions of the same source entity from appearing as separate cards in one collection.

## Active Hand preferences

Active-Hand selection is revisioned per surface. The same operator Hand can be active in Hapa Dev Proto and Hapa Avatar Builder, while either surface may deliberately switch to an avatar-specific Hand. A cleared preference is retained as a revisioned tombstone so concurrent changes still conflict correctly. Preference changes also carry provenance and an inverse.

`activeForSurfaces`, when present, limits where a collection may be selected. The owning source system remains visible on each collection and entity reference.

## Host persistence

Consumers store the resulting CollectionLedger as a canonical host record and send commands through the shared host. They must not write another local Hand reducer or mutate the host snapshot file directly. UI code may optimistically display a held token, but should clear it only when the shared command is accepted or the user explicitly cancels.
