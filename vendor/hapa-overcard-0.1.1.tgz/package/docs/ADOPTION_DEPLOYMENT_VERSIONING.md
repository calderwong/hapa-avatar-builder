# Hapa node adoption, deployment, and versioning

This is the standard path for adding Universal Overcard to a third Hapa node. The canonical behavior owner is `@hapa/overcard`; a consumer owns only entity resolvers, native renderers, HostTarget registrations, and process adapters.

## Adopt a promoted release

1. Obtain a promoted `releases/<version>/manifest.json` and sibling tarball from the canonical release process.
2. Run `hapa-overcard verify-release --release-manifest /path/to/manifest.json`.
3. Run `hapa-overcard scaffold --node-root /path/to/node --node-id hapa-example-node --release-manifest /path/to/manifest.json`.
4. Install the exact version using the approved Hapa registry or checksum-identical tarball. Verify `overcard-release.lock.json`; never substitute a mutable folder.
5. Mount `OvercardProvider` once. Register native renderers by stable id and HostTargets with typed sockets/effects.
6. Publish a compact EntityRef catalog and lazy resolvers. Do not hydrate whole avatar, card, item, or scene stores during Hand bootstrap.
7. Run package conformance plus node build, accessibility, security, migration, and cross-app canary.
8. Register node, interfaces, source owner, subscribers, safe writeback, and human authority gates before promotion.

`test/installer.test.mjs` is the automated third-node proof: it pins `0.1.1`, writes the checksum lock, creates only a thin adapter, and refuses overwrite.

## Development link versus packaged artifact

| Context | Allowed dependency | Truth |
| --- | --- | --- |
| Canonical development | canonical checkout | repository root |
| Local consumer iteration | explicit `file:` link recorded as `developmentSourceLink` | canonical checkout only |
| Canary/package/release | exact semver plus SHA-256/SRI lock | promoted immutable artifact |
| Production | approved registry artifact or checksum-identical tarball | promoted manifest |

`packaging.sourceLinksAllowed` must be `false`. A `file:` link is never release evidence and must not appear in a packaged consumer manifest.

## Compatibility and version policy

- Schemas have independent majors such as `hapa.formation.v2`. Unknown fields are forward-compatible; unsupported majors fail closed.
- Package `MAJOR` breaks public subpaths or supported schema majors. `MINOR` adds compatible fields/components/adapters/transports. `PATCH` fixes behavior without changing contracts.
- Consumer locks pin exact version and checksum. Runtime negotiation compares protocol, schemas, renderers, HostTargets, and processes.
- Deprecation requires a replacement, warning, migration, removal criteria, and at least one supported minor. Shims receive no new behavior.

## Upgrade gate

Back up event log, snapshot, legacy state, and lock; run migration plan/dry-run and review loss/conflicts; run canonical and both consumer canaries; verify performance, deep links, security, docs, and human gates; promote only the checksum that produced the passing report.

## Rollback gate

Restore the prior exact package/checksum and pre-migration state, then replay only compatible events. Never downgrade an event log in place. Preserve candidate, report, lock, backups, and decision. If the old version cannot read a new schema major, keep the node offline/read-only until a reviewed reverse migration exists.
