# Pickup sources

`OvercardPickupActions` and `useOvercardPickupSource` share one transient held entity at the root provider. A seven-pixel pointer threshold keeps ordinary click/select separate from pickup. Ctrl/Command+Enter is the keyboard pickup command. Native drag remains enabled; the hook adds `application/vnd.hapa.overcard.entity+json` without replacing other data-transfer types.

“Add to Hand” commits a canonical copy only after the active Hand accepts capacity and duplicate rules. Read-only sources use the same copy operation and are never mutated. Held state, pointer coordinates, DOM nodes, and native files are not persisted.
