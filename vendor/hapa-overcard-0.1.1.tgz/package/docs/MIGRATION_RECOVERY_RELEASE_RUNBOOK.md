# Migration, recovery, troubleshooting, and release runbook

## Before any migration

1. Stop writes or put both consumers in read-only mode.
2. Record current package version/checksum, host revision/last hash, consumer locks, and active bindings.
3. Copy event log, compact snapshot, legacy browser keys, Electron control-plane file, and source-owned stores to immutable timestamped backups. Record SHA-256.
4. Run migration planning/dry-run. Review every `review_required`, conflict, unsupported schema, and lossy conversion. No review means no write.
5. Keep legacy readers and the previous exact package for at least one rollback-capable release.

For the one-time shared-host cutover, all consumers must be stopped before `migrateLegacyOvercardDataRoot` runs. Migrate Dev Proto's app-private `overcard/` root into `~/.hapa/overcard`, verify the receipt and copied hashes, then start either Dev Proto or Avatar Builder. If Builder created an empty live canonical host first, migration returns `target-in-use`; stop both consumers and retry from the preserved legacy source. This ordering constraint ends once a valid migration receipt exists—normal launch order is then independent.

Migration writes are idempotent by migration id/version/source checksum. Re-running the same input returns the prior receipt; it does not duplicate members, placements, attachments, or Formations.

## Restore pre-migration state

1. Stop the host and consumers; retain failed logs/receipts.
2. Move the candidate event/snapshot pair aside—never edit or truncate them.
3. Restore the matching pre-migration event log and snapshot together and verify snapshot hash/checkpoint.
4. Restore Dev Proto legacy keys from `hapa.overcard.migration.hapa-dev-proto-overcard.v1.backup` and Electron `formations/control-plane.json` when required.
5. Restore prior consumer locks and exact package checksum.
6. Reopen host, inspect revision/hash, run migration/host/two-app tests, then allow writes.

## Recover a stranded or conflicting card

- Held/stuck card: press Escape/Cancel. The source is unchanged until accepted commit.
- Menu attachment: use **Detach + return**; use Undo if it was the wrong item.
- Offscreen CSS/3D card: use **Recover all**, then a deterministic layout.
- Offline queued command: inspect pending id/type/record key. Retry only after reconnect; choose explicit rebase for an understood stale revision or Discard to preserve host truth.
- Concurrent conflict: compare record/revisions and provenance. Export both semantic versions, choose rebase/merge/reject, and append the decision. Never silently last-write-wins.
- Missing source entity: keep the reference unavailable and navigate to source; do not synthesize a replacement identity.

## Failure signatures

| Signature | Meaning | Safe next action |
| --- | --- | --- |
| `overcard_queued` | host unavailable; write is not shared | reconnect, inspect pending, explicit retry/discard |
| `overcard_conflict` / HTTP 409 | expected revision is stale | reload, compare, explicit rebase/merge |
| HTTP 401 | missing/wrong bearer token | fix local secret reference; never paste into state |
| HTTP 422 `unsafe_payload` | credential/raw memory/nonportable value | replace value with a safe reference |
| `Snapshot hash mismatch` | compact snapshot tampered/mismatched | stop, preserve evidence, restore matching backup |
| `Event hash chain mismatch` | log altered/corrupt/out of sequence | stop; never skip line; restore verified pair |
| telemetry `absent` | node published no projection | inspect capability/telemetry producer; not zero |
| telemetry `stale` | projection exceeded freshness budget | reconnect producer; do not show healthy |
| responsibility remains `staged` | gate/grant/runtime missing | inspect policy reasons; use process default |
| embedded `origin_denied` | child origin not allowlisted/session mismatch | verify exact origin; do not add wildcard |
| host `origin-blocked` | compatible host does not emit CORS for this renderer | run canonical ensure with the exact loopback origin; inspect `missingOrigins` |
| legacy migration `target-in-use` | a live canonical host or different canonical durable state already exists | stop all consumers; inspect both roots and receipt; never overwrite |
| unsupported schema major | incompatible consumer/package | migrate or roll back; never coerce |

## Release checklist

Automated evidence:

- `npm test` in canonical package (schemas, policy, migration, host, sync, security, accessibility, installer, pack, real two-app E2E).
- Builder production build and focused Overcard canary.
- Dev Proto TypeScript and focused Overcard/capability/run-context canary.
- `npm run release:local` creates manifest, checksum, consumer locks, bounded canary/performance/release-gate reports, and an automated migration/rollback restoration proof; status must be `promoted`.
- Verify artifact with `hapa-overcard verify-release` and verify docs are inside dry-run pack.

Human evidence:

- Review migration plan and any loss/conflict decisions.
- Exercise Hand add/reorder/remove, menu attach/detach/return, Formation save/load, Red→Hell Week fallback, embedded Bank read-only behavior, and degraded UI.
- Review threat model, compatibility matrix, performance budgets, package diff, provenance, and rollback drill.
- Approve external registry publication separately; local promotion does not authorize publishing.

## Rollback checklist

- Trigger: failed canary, new P0/P1 regression, integrity mismatch, unsafe data path, performance budget breach, or rollback drill failure.
- Pause bindings and writes; preserve candidate artifact/report/events.
- Restore prior package/checksum and matching data backup as above.
- Verify health, hash chain, Hand/slot parity, process defaults, and both consumers.
- Append rollback reason, affected versions/revisions, evidence links, operator, and follow-up task to the board.

Exact automated evidence lives in `releases/<version>/canary-report.json`, `performance-report.json`, and `release-gates-report.json`; human decisions live as append-only board comments/review events. A release is incomplete without both.
