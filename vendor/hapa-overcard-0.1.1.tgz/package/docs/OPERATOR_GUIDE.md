# Operator guide: Hand, placement, slots, and Formations

## Carrying cards

The Personal Hand belongs to the operator and can appear in both apps. Avatar Hands/Decks remain privately scoped to that avatar. Selecting a Hand changes the active destination for the current surface. A held card is transient: the source stays intact until a destination accepts the command. “Add to Hand” copies; move stays within one owner; assign/lend records cross-owner custody; return follows that custody home.

Click selects. Drag beyond the pickup threshold or Ctrl/Command+Enter picks up. Alt+Enter adds the focused source to the active Hand. Native file/media drag remains available. A capacity or duplicate rejection leaves the source untouched. Escape cancels held/selected transient state.

## Spatial surfaces and Formations

CSS-3D and Three.js fields use the same semantic commands. Arrow keys nudge a selected card; brackets change depth. Grid, fan, stack, and line are reversible layout presets. “Recover all” returns offscreen placements to a visible grid. Reduced-motion removes transitions. A Formation saves members, roles/groups, semantic pose, and optional bindings; camera/DOM/viewport state stays local.

## Attaching to an application host

Before staging, a slot states accepted types, capacity, and effect. Staging does not activate. View context changes what a view presents. Process context adds bounded inputs to a process. Responsibility proposes who manages/advises/reviews/operates; “Request authority” must pass trust, authorization, capability, permission, lease, secret-reference, and human-gate checks.

Every attached item shows mode and state in text. Inspect shows provenance, health, input/output, effective context, and fallback. Disable pauses it. Detach + return atomically removes context and puts the card on the Hand recovery surface. Replace returns the displaced card. Undo replays the inverse command. Visual proximity, Formation membership, or a healthy color never grants authority.

## Degraded and recovery states

- Offline: shared mutations queue locally but are not claimed shared; reconnect, then explicitly retry/rebase/discard.
- Conflict: inspect newer host state; rebase only after confirming intent.
- Degraded target: inspect missing capabilities and fallback; pause or detach if unsafe.
- Missing card face: the portable fallback identity remains usable; open its source resolver.
- Lost/offscreen card: Recover all, then Detach + return if attached.
- Full Hand: switch Hand/Deck, return/eject another card, or cancel; the source is not eaten.
- Revoked responsibility: runtime uses declared process-default/pause/fail fallback and telemetry attributes the change.

Dev Proto and Avatar Builder use these same terms and shared controls. Native card faces differ, but custody, placement, attachment, Formation, responsibility, and recovery semantics do not.
