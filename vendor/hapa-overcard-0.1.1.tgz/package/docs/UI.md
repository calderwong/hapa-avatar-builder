# Hapa Overcard UI Surface

Overcard supplies shared React and Electron primitives that consumer nodes
embed in their own operator interfaces:

- a scoped personal/avatar Hand;
- keyboard-accessible held-card, return, undo, and recovery flows;
- typed host slots with health and provenance;
- spatial Formation projections; and
- explicit responsibility state that never follows visual proximity alone.

Consumers render their own domain entities but must preserve Overcard's stable
entity IDs, provenance, revision/conflict feedback, and reversible operations.
The package has no standalone desktop window. Test and inspect it through a
consumer integration; `npm test` includes React, Electron channel, and
cross-consumer conformance coverage.
