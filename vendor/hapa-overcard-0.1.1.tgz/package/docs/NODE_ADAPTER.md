# Hapa Node Adapter Contract

Every adopting Hapa node publishes one `hapa.overcard-node-adapter.v1` manifest. It is the deployment declaration for the canonical package, not another implementation of Overcard behavior.

The manifest names the node and package version; supported protocol/schema versions; host mode; required and optional nodes; entity resolvers; stable renderer IDs; HostTargets; process adapters; conformance commands; and HTTP, Electron, P2P, and UI discovery coordinates. Its embedded capability envelope uses the same shape returned by all transports.

## Discovery is not authority

A static manifest must set `trusted` and `authorized` to false. `negotiateCapabilities` reports installation, runtime availability, and version compatibility from observations, but sets trust and authorization only when separate explicit grants match the manifest node ID. HTTP response, Electron channel, P2P topic, UI readiness, or package installation alone can never create either grant.

Authorization also requires trust. A matched authorization grant without a matched trust grant remains unauthorized.

## Adoption steps

1. Install one pinned `@hapa/overcard` package/workspace source.
2. Create the adapter manifest and include `hapa-overcard` in `requiredNodes`.
3. Register compact entity resolvers and renderer IDs; keep render functions runtime-local.
4. Register typed HostTargets and process adapter preview/execution routes.
5. Expose the same capability envelope through configured HTTP/Electron/P2P/UI projections.
6. Run every `conformanceCommands` entry.
7. Add trust and authorization through the owning operator/policy system, never by editing the manifest flags.

Hapa Avatar Builder's canonical descriptor is `../hapa-avatar-builder/overcard-adapter.json` in a sibling checkout. It corrects the historical required-node mismatch by requiring `hapa-overcard`; `hapa-dev-proto` is optional because Builder must retain reduced standalone operation.
