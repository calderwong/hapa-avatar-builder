# Shared React Integration

`@hapa/overcard/react` is the one React state and rendering boundary for every Hapa consumer. Applications mount `OvercardProvider` with a repository adapter; they do not create app-specific Hand, Placement, Formation, attachment, or responsibility reducers.

## Storage-agnostic store

`OvercardStore` contains no React dependency. It accepts an adapter with `load`, `commit`, and `subscribe`, plus injectable clock and ID factories. This supports the loopback host in production and deterministic in-memory behavior in tests. Snapshot revisions are monotonic, commands are serialized, adapter failures become explicit degraded state, and command focus is part of the shared UI projection.

The provider exposes stable hooks for:

- catalog and EntityRefs;
- Hand/Deck/Set collection ledger;
- Placement and Attachment ledger;
- Formations and ResponsibilityBindings;
- typed HostTargets;
- telemetry and command focus;
- full status/revision/error snapshot.

Hapa Dev Proto and Hapa Avatar Builder should differ only in their repository/node adapter registrations and native renderers, not hook or reducer behavior.

## Renderer registry

Consumers register native entity faces under stable IDs such as `avatar-builder-avatar`, `hapa-card-face`, or `tarot-card-3d`. Shared records persist only that renderer ID and an EntityRef. The registry's React render function remains runtime-local and is never placed in core state, host events, snapshots, or migrations.

`EntityFace` first resolves a requested compatible renderer ID, then an entity-type renderer, then an accessible text fallback. This allows native artwork to survive adoption without forking the interaction engine.

## Themes and errors

`OvercardThemeBoundary` maps supplied tokens to `--overcard-*` CSS variables inside `.hapa-overcard`; consumer themes may project their own tokens without changing shared behavior. `OvercardErrorBoundary` contains renderer failures and exposes a stable alert fallback.

## Testing

`@hapa/overcard/testing` provides `InMemoryOvercardAdapter`, deterministic IDs, and a fake clock. Provider tests should mount the same hook surface used by the app and verify renderer IDs, subscription updates, stale revision rejection, command provenance, and degraded behavior.
