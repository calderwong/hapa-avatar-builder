# Hapa Overcard CLI

The `hapa-overcard` command is the package-adoption and release-verification
surface. It does not start a shared host; a consumer node owns that lifecycle.

```bash
node bin/hapa-overcard.mjs
hapa-overcard verify-release --release-manifest releases/<manifest>.json
hapa-overcard scaffold --node-root /path/to/node --node-id example-node --release-manifest releases/<manifest>.json
```

| Command | Purpose | Write behavior |
| --- | --- | --- |
| `verify-release` | Verify the promoted package artifact checksum and release metadata. | Read-only. |
| `scaffold` | Create a consumer adapter, lock record, and package dependency after a promoted release is verified. | Writes only the named consumer files. |

Successful operations emit JSON and exit `0`. Invalid flags, non-promoted
releases, or checksum mismatch exit non-zero. Never pass secrets on the
command line; consumer host tokens belong in an OS-managed secret reference
or process environment.
