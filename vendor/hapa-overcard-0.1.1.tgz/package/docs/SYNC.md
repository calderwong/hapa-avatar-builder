# Cross-App Live Sync

`OvercardSyncAdapter` is the canonical browser-safe bridge between `OvercardStore` and the loopback host. Hapa nodes should wrap it only to merge app-owned compact catalogs or add node-specific command codecs; they must not implement another SSE, conflict, or offline queue.

## Bootstrap and resume

The adapter loads one host snapshot, remembers its revision and compact records, then subscribes to `/events?afterRevision=N`. Ordered events update the local projection directly, so Hand, Placement, Formation, attachment, and responsibility records appear in other apps without reload. A revision gap triggers a fresh snapshot before any later event is applied.

Stream failure is labeled `reconnecting` and retries with bounded exponential backoff. A normal unexpected stream close is treated as a failure rather than a successful end. Resubscription always resumes after the last accepted host revision.

## Optimistic concurrency

Every UI command is encoded with the adapter's last host revision and an idempotency key. HTTP 409 becomes `OvercardConflictError` and a visible pending record containing only command/type/record key/revisions and error summary. The original payload remains internal to the adapter for an explicit retry.

Conflict resolution is operator-controlled:

- Retry preserves the original expected revision.
- Rebase explicitly substitutes the current known host revision.
- Discard removes the local pending record.

The adapter never silently applies last-write-wins.

## Offline behavior

Network failure stores a pending command locally, emits offline/degraded sync state, and throws `OvercardQueuedCommandError`. The caller therefore cannot interpret the action as a shared commit. No optimistic shared projection is applied. `pendingCommands()` returns redacted summaries for UI recovery controls; a successful explicit retry applies the real host event and removes the pending record.

## Consumer state

`useOvercardSyncStatus()` exposes connection state, pending/conflict counts, and last event revision. Builder's root status surface uses it to label offline state and offer retry, explicit rebase, and discard controls beneath modals/toasts according to the shared layer contract.
