# Two-app consumer proof

`test/two-app-consumers.test.mjs` is the release gate proving that Hapa Avatar Builder and Hapa Dev Proto consume one Overcard implementation instead of maintaining parallel feature copies.

The test imports each application's production adapter factory and connects both to a real loopback Overcard HTTP/SSE host backed by the append-only file repository. It covers:

- Builder creation of a shared Hand containing an Avatar, Card, and Deck.
- Dev Proto reorder and removal with canonical collection reducers.
- Builder placement and attachment of Avatar, Card, and Deck entities to Hell Week menu sockets.
- Dev Proto detach and Return-to-Hand as one canonical placement transaction.
- exact preservation of Formation members, roles, poses, Responsibility Binding, and provenance.
- host shutdown, an explicitly queued offline Builder command, repository reopen, retry with rebase, and Dev Proto SSE reconnection.
- concurrent Builder and Dev Proto edits, visible stale-revision conflict, and explicit rebase convergence.

## Consumer contract

Every Hapa node integrates through its thin adapter factory and `@hapa/overcard`. A consumer may contribute catalog and renderer projections, but Hand, Deck, placement, attachment, Formation, Responsibility, persistence, sync, and conflict behavior stay in the canonical package.

Adapter factories must accept a host URL and optional bearer token. Test and deployed consumers may also tune reconnect timing, but they must not replace the canonical sync protocol. Offline writes are never represented as shared: they remain visible pending commands until an operator retries or discards them.

Run the proof from the canonical package:

```sh
npm run build
node --test test/two-app-consumers.test.mjs
```

This test must use the real consumer modules under `hapa-avatar-builder/src/overcard/hostAdapter.js` and `hapa-dev-proto/src/overcard/canonicalAdapter.ts`; substituting in-memory descriptors does not satisfy the gate.
