# Compatibility matrix

The machine-readable source is [`COMPATIBILITY_MATRIX.json`](./COMPATIBILITY_MATRIX.json). Release promotion verifies it against the package metadata and both consumer locks.

| Component | Supported contract |
| --- | --- |
| `@hapa/overcard` | exact `0.1.1` package and SHA-256 consumer lock |
| Node.js | `>=20` |
| React | `>=18 <20` |
| Electron host bridge | `>=28` |
| Avatar Builder | node id `hapa-avatar-builder`; canonical package `0.1.1` |
| Dev Proto | node id `hapa-dev-proto`; canonical package `0.1.1` |

The Avatar Builder and Avatar Dashboard are separate products. A missing Builder Formation surface must request `hapa-avatar-builder`, never `hapa-avatar-dashboard`. A schema-major, protocol, runtime, migration, or checksum mismatch blocks promotion; it is not silently coerced.

Every promoted release includes canonical/consumer canaries, scale and memory measurements, documentation checks, migration coverage, and an automated rollback restoration proof. See the [release pipeline](./RELEASE_PIPELINE.md) and [migration/recovery runbook](./MIGRATION_RECOVERY_RELEASE_RUNBOOK.md).

`0.1.1` is an atomic local-host security cutover, not a rolling host reuse release: its origin-denial, dynamic registry, and JSON-only command guarantees are absent from `0.1.0`. Stop the `0.1.0` owner, migrate legacy state, then launch both consumers on `0.1.1`; the supervisor intentionally reports an older live host as incompatible.
