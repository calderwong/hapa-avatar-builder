# Spatial overlay and Formations

`useOvercardSpatialSurface` is the shared semantic command layer. CSS-3D hosts mount `OvercardSpatialSurface`; Three.js hosts provide a `projection(model)` renderer and call the same `model.execute` commands. Renderer objects, cameras, DOM geometry, and viewport state never enter canonical records.

Only the surface holding `commandFocus` receives global movement shortcuts. Arrow keys nudge the selected placement, brackets change depth, and Escape clears held/selected transient state. Pointer and touch use ordinary buttons and pointer events; status changes are announced in a live region. `prefers-reduced-motion` removes transitions and is exposed to custom projections.

Grid, fan, stack, line, Formation application, and Recover All compile into revision-checked placement-ledger commands with inverse receipts. Pickup remains transient until an accepted placement commit, and cancellation never removes the source.
