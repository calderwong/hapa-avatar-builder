# Hapa Overcard API / CLI / UI Parity

| Surface | Verified contract | Evidence |
| --- | --- | --- |
| API | Loopback shared-state host with health, capabilities, snapshot, command, and SSE routes. | `src/host/server.ts`, `docs/API.md`, host/client tests. |
| CLI | Release verification and safe consumer adapter scaffold. | `bin/hapa-overcard.mjs`, `docs/CLI.md`. |
| UI | Shared React Hand/slot UI plus Electron capability channels for consumer integration. | `src/react/`, `src/electron/`, `docs/UI.md`. |

Parity means the same package contracts, stable IDs, capability envelope, and
provenance rules are available to every surface. It does not mean a consumer
is trusted, authorized, or running; those are separate, explicit runtime facts.
