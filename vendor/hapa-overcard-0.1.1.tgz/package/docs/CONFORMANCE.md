# Packed-package conformance

`runCanonicalConformance(fixtures)` is exported from `@hapa/overcard/testing`. It verifies the full schema registry, Red/Hell Week and Avatar/Tarot golden records, deterministic legacy migration, future-field tolerance, unsupported-major rejection, and a 1,000-member Formation.

The package test packs and installs the actual tarball into an empty consumer. ESM and CommonJS consumers must produce identical reports using only public exports. The installed host is then tested for idempotent commands, compaction, append-log rebuild, and hash parity; installed Electron channels are allowlisted. Source-relative imports are unavailable in the temporary consumer by construction.

Run `npm run check` before publishing. Any report mismatch, missing packed artifact, unsupported version acceptance, event rebuild difference, or non-public import is a release blocker.
