# Host slots and attachment inspector

`OvercardHostSlots` renders exact button hitboxes from a node's registered target and socket definitions. It previews accepted entity types and the slot effect before committing. A drop creates only a **staged** placement/attachment; context activation is a separate action, and responsibility activation must pass a host-supplied authorization callback that returns a binding ID.

Each attachment spells out mode and lifecycle status in text. Inspect exposes provenance, health, input/output, effective context, and fallback. Disable pauses active context. Detach + return atomically removes the attachment and moves its placement to the canonical Hand surface, so the reverse path remains visible and the source cannot disappear. Replace returns the displaced entity to that same recovery surface.

Capability discovery and compatibility never imply trust or authority. Hosts compile policy and resolve runtime context outside this visual component, then provide redacted results for inspection.
