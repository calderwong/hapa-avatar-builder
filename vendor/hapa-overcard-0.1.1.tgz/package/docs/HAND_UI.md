# Shared Hand and Deck UI

`OvercardHand` is the reusable always-available collection tray for Hapa nodes. It reads the canonical CollectionLedger through shared hooks and persists accepted ledger states through `OvercardStore`; consumer apps supply only surface/operator identity, theme tokens, and entity renderers.

The tray provides:

- explicit Personal/Avatar owner labels and collection switching;
- Hand, Deck, and Set tabs with counts;
- four explicit presentation modes: `docked-minified`, `docked-manager-open`, `floating-compact`, and `floating-expanded`;
- stable native entity faces through renderer IDs;
- transient pickup with visible origin and cancel;
- source-safe drop that clears the held token only after a shared commit;
- capacity/full feedback and conflict errors;
- Eject and replayable Undo using canonical inverse commands;
- empty-state personal Hand bootstrap;
- arrow-key focus, Enter pickup, Delete/Backspace eject, Escape cancel, buttons usable by touch, and semantic list/tab/status roles.

Semantic collection state never enters localStorage or another app reducer. Versioned, surface/operator-scoped presentation preference and floating geometry may use consumer-provided local preference storage. Offline shared mutations reject and are not silently queued; the held token and source collection remain intact.

The default dock is a bounded Header summary with count/capacity, up to three previews, held state, Manage, and Detach. Manage opens the package-owned Hand/Deck/Set manager in the `handDisclosure` layer; Library and collection-type intents are router-neutral callbacks. Floating uses a body portal, persisted/clamped geometry, pointer/touch and keyboard movement, Reset, a resident Dock return affordance, and focus restoration. Named layers are documented in `LAYER_CONTRACT.md`.

`OvercardConnectionStatus` is the compact companion presenter. It distinguishes connecting, reconnecting, online, offline, wrong service, origin blocked, unauthorized, incompatible, pending, and conflict states. Its disclosure keeps exact errors, revision, retry timing, and explicit Retry/Rebase/Discard; reconnecting the host is not represented as synchronizing pending commands.

Hapa Avatar Builder and Hapa Dev Proto both mount this component in their persistent Headers and register only native renderers and route/host callbacks. Neither consumer may copy presentation, collapse, floating, recovery, or mutation logic.
