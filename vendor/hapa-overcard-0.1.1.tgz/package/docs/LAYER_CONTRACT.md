# Overcard layer contract

Overcard uses named layers rather than consumer-specific large `z-index` values.

| Token | Value | Purpose |
| --- | ---: | --- |
| `content` | 0 | route content and 3D canvas |
| `header` | 20 | persistent app shell and in-flow docked Hand |
| `routeOverlay` | 30 | view popovers, inspectors, and native HUD overlays |
| `floatingUtility` | 40 | detached Hand and equivalent movable utilities |
| `handDisclosure` | 45 | manager/recovery disclosure belonging to the active Hand |
| `toast` | 50 | ephemeral confirmation |
| `modal` | 60 | dialog and focus trap |
| `criticalPrompt` | 70 | blocking safety/authority confirmation |

TypeScript consumers use `OVERCARD_LAYERS` or `overcardLayer`. CSS consumers use the matching `--hapa-overcard-layer-*` variables scoped by `.hapa-overcard`.

Docked Hand is normal Header flow at `header`; it is not a floating overlay. Detached Hand uses `floatingUtility`. A manager or recovery popover may use `handDisclosure`, but must remain below a modal focus trap. Consumers must not raise a Hand above modal or critical layers.

Fullscreen and embedded surfaces must explicitly choose one of two behaviors:

1. retain the Header/Hand anchor in the fullscreen shell; or
2. intentionally suppress it while providing an accessible, deterministic return to the owning shell.

An arbitrary fullscreen `z-index` does not override this contract. Tarot and other 3D canvases remain content/route-overlay surfaces unless they are inside a true modal.
