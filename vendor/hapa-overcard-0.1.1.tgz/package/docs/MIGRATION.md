# Migration and reconciliation

`planLegacyMigration` is the environment-neutral planner. A node supplies explicit source adapters and a SHA-256 implementation; the planner sorts sources, checks every converted target against canonical state, and emits deterministic idempotency keys. Equal targets are `unchanged`. Different targets, duplicate claims, unsupported schemas, conversion failures, and intentionally lossy adapters enter `review` and are never written silently.

`runFileMigration` is the Node/Electron coordinator. Before conversion it copies every source to a checksum-named backup. It writes only when the complete plan has no review items, commits through the append-only host repository, compacts the canonical snapshot, and atomically saves a receipt containing checksums, writes, conflicts, backup locations, and rollback instructions. Rerunning the same migration returns the immutable receipt, so it cannot duplicate records or overwrite later state.

Consumers must retain the evidence directory and their pre-migration host backup until release acceptance. Rollback restores legacy files and the complete canonical event-log/snapshot pair on the previous package version; append-only history must never be surgically edited.
