# Placement and Attachment Ledger

The ledger is the semantic source of truth for where an entity is placed and what context it contributes to a typed host. It replaces independent Hand, overlay, menu-slot, dock, Tarot-field, Formation, and responsibility drag state with one serializable transaction format.

## Preview, reject, commit, inverse

Every gesture compiles to `hapa.placement-command.v1` with an expected ledger revision, actor/time/source/trace provenance, and atomic operations. Preview applies that command to an immutable clone and returns its command hash plus acceptance issues. A UI can record an explicit rejection without mutating the ledger. Commit rechecks the revision and rules; an accepted receipt contains the new state and a replayable inverse command.

This means a drag never removes the source by itself. Hand/Deck collection changes and Placement changes are committed through their authoritative ledgers after preview acceptance. A cancelled or rejected preview leaves both sources untouched.

## Operations and helpers

- Placement upsert/remove for Hand, overlay, menu, dock, 3D field, or Formation addresses.
- Attachment upsert/remove for view context, process context, or staged responsibility.
- Semantic zone reorder containing every placement exactly once.
- Return Home / Return to Hand by moving to an explicit address.
- Replace by atomically detaching and returning the displaced entity before committing the replacement.
- Recover All by supplying an explicit destination for every placement on a surface.
- Undo by committing the receipt's inverse against the resulting ledger revision.

Inverse commands also restore zone order, linked attachments, displaced destinations, and domain revisions rather than merely deleting the newest object.

## Placement is not authority

A responsibility attachment may be staged visually. It cannot become active without an explicit ResponsibilityBinding id, and even an active binding is constrained by the independent runtime policy compiler. Neither proximity nor a menu-slot occupancy grants tools, memory, credentials, or process permission.

## Shared vs. renderer-local state

Shared state may contain stable EntityRefs, renderer IDs, semantic surfaces/zones/slots, world-space pose, order, lifecycle, provenance, and typed host references. The portable-state guard rejects functions, cycles, DOM elements/rectangles, camera, viewport, component, and HUD state.

Camera orbit, zoom, viewport dimensions, pointer capture, CSS transforms, hover state, HUD layout, and similar presentation preferences remain in each renderer. They can project the same semantic placement differently without forking its meaning.

## Failure behavior

Commits fail atomically on stale ledger or object revisions, occupied slots, duplicate move placements, invalid schemas, malformed orders, non-portable data, mismatched placement/attachment entities, linked-placement deletion before detach, or active responsibility without a binding. A replace or Recover All operation either commits every listed change or none.
