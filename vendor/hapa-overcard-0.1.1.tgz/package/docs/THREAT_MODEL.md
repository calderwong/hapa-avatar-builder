# Overcard privacy, authority, and transport threat model

## Assets and trust boundaries

Protected assets are private avatar memory, credentials/keys, active authority, budgets, tools, source-owned records, event integrity, operator intent, and the distinction between visual context and executable identity.

Trust boundaries exist at pickup/drop input, React consumer adapters, loopback HTTP/SSE, Electron IPC, iframe `postMessage`, deep links, P2P envelopes, process adapters, migration files, and package promotion. Discovery, installation, running state, compatibility, trust, and authorization are separate facts. None implies another.

Threat actors include malformed cards, stale or compromised consumers, hostile iframes/origins, untrusted peers, a process advertising capabilities it does not own, accidental operator actions, tampered local files, and dependency/artifact substitution.

## Authority-bearing flows

| Flow | Human gate | Effective policy | Deterministic fallback |
| --- | --- | --- | --- |
| Pick up / place / Formation arrange | explicit pickup/drop or keyboard command | presentation only | preserve source; cancel/return |
| Attach view/process context | explicit Stage then Activate context | typed socket accepts entity; no authority effect | remain staged or detach/return |
| Attach Avatar as responsible principal | Request authority plus socket human gate | binding ∩ operator ∩ process ∩ runtime ∩ trusted card constraints | process default, pause, or fail |
| Start Hell Week/process run | explicit Prepare/Run; active nonexpired binding | freeze revisioned RuntimeContext at run start | process-owned default runtime |
| Memory writeback | `memory:writeback` approval for each policy requiring it | classification/visibility/source intersection; reference-only secret resolution | read-only memory or pause |
| Tool/provider/secret access | process run gate plus allowed ref scheme | refs resolve inside owning runtime; no portable value | deny tool/ref; pause/fail |
| Embedded Bank/Echos action | child advertises action and parent allowlist accepts it | origin+schema+version+session+surface capability intersection | read-only context or typed rejection |
| P2P transfer/capability discovery | explicit trust and authorization grant after signature/expiry checks | remote envelope grants nothing by itself | local-only/read-only, reject transfer |
| Migration | operator reviews plan and any lossy/conflicting record | backup+checksum+idempotency | no write; restore backup |
| Package promotion | human-controlled publish after automated canaries | exact version/checksum/SRI | reject candidate; retain previous release |

Visual placement never grants authority. An active-looking card without a verified binding, human gate, compatible trusted runtime, permissions, budget, and lease is non-executable.

## Data minimization

Portable manifests may contain EntityRefs, collection membership, semantic pose, safe settings, reference ids, capability ids, allowed permission names, budget bounds, provenance, and secret references.

They explicitly exclude raw private memory, prompt transcripts, credential values, tokens, private keys, active leases/capability handles, runtime functions, renderer objects, unredacted input/output, and implicit grants. A secret reference is not a secret value. Embedded projections further exclude bindings, provenance paths, resolver internals, and the full React store.

## Transport controls

- HTTP host binds loopback only, uses optional bearer authentication, bounded JSON, no-store responses, an exact persistent origin registry, expected revisions, idempotency, and SSE replay. Any request carrying a denied Origin receives 403 before routing, and `/commands` accepts only `application/json`, preventing blind form-like writes from hostile pages.
- Opaque `Origin: null` is not a baseline grant. A packaged file renderer may request it as a compatibility exception, but production consumers should move to a stable custom scheme or authenticated preload/IPC bridge because opaque origins cannot be distinguished from each other.
- Electron accepts only allowlisted Overcard IPC channels; capabilities remain untrusted/unauthorized until explicit grants.
- Embedded messaging requires exact HTTP(S) origin, schema, protocol version, surface, child-window session, capability, and action. Responses target the verified origin, never `*`.
- P2P presence is signed, expires, and uses the same capability envelope across UI/HTTP/IPC/P2P. Peer discovery is not trust.
- Deep links carry identifiers/revisions only and must be parsed by the owning node; they carry no credential or authority.
- Files use append-only hash-chained events, 0600 snapshots/logs, atomic compaction, checksums, and immutable backups.

## Risk-to-test map

| Risk | Test evidence |
| --- | --- |
| Credential/private memory leak online or offline | `security-recovery.test.mjs`, `host.test.mjs`, contracts RuntimeContext tests |
| Visual placement escalates authority | `policy.test.mjs`, placement-ledger responsibility tests, ADR-0002 |
| Missing/expired/revoked gate still executes | `policy.test.mjs`, Builder Red/Hell Week tests, Dev Proto run-context tests |
| Hostile iframe or overbroad Bank action | Builder `overcard-embedded-bridge.test.mjs` |
| Untrusted peer/capability becomes authorized | canonical `node-adapter.test.mjs`, Dev Proto `formationCapabilities.test.mjs` |
| Stale/concurrent/offline data loss | `sync.test.mjs`, `two-app-consumers.test.mjs`, `security-recovery.test.mjs` |
| Event/snapshot tampering | `host.test.mjs` |
| Stuck/lost/offscreen card | interaction/accessibility matrix and placement/spatial tests |
| Artifact/source substitution | installer test, consumer locks, release canary report |

## Incident response

Pause or revoke the binding, stop the affected node, retain append-only evidence, rotate referenced credentials at their owner, verify event/snapshot hashes, restore from immutable backup if needed, and fall back to process defaults. Do not delete or rewrite the incident trail. Re-enable only after the threat-specific test and both consumer canaries pass against a new exact checksum.
